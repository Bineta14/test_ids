#### fonctions de mon package

# Plot density

#' @export
densite_Bineta<-function(n){
  plot(density(rnorm(n)))
}